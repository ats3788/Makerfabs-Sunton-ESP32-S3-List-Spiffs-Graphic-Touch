

#define LGFX_USE_V1
#include <LovyanGFX.hpp>

#include <Arduino_GFX_Library.h>
#include <TAMC_GT911.h>
#include <Wire.h>
#include "Matouch7.h"


#include "FS.h"
#include "SPIFFS.h"
#include <TJpg_Decoder.h>
#include <lvgl.h>

#include "lgfx/v1/LGFX_Button.hpp"

//#include "BmpClass.h"
#define noDebug

#define SCREEN_HD

#define I2C_SDA_PIN 17
#define I2C_SCL_PIN 18
#define TOUCH_INT -1
#define TOUCH_RST 38
#define lcd_BL 10

#ifdef SCREEN_HD
#define SCREEN_W 1024
#define SCREEN_H 600
#define TOUCH_ROTATION ROTATION_INVERTED
#endif

#define TOUCH_WIDTH 1024
#define TOUCH_HEIGHT 600


#define FORMAT_SPIFFS_IF_FAILED true

#define BitmapMoonX 65

static const char* const Wind[] = {"N","W","E","S","NE","NW","SE","SW"};
static const char* const Weather[] = {"clear-day","clear-night","cloudy","drizzle","fog","hail","lightRain","partly-cloudy-day",\
"partly-cloudy-night","rain","sleet","snow","thunderstorm","unknown","wind"};


#define BitmapWindX 55
#define BitmapWeatherX 55

char Buffer[30];

uint16_t w = 0, h = 0;

LGFX lcd;
//LGFX_Device lcd;

LovyanGFX *tft;


LGFX_Sprite sprite(&lcd);

LGFX_Button Button;


TAMC_GT911 ts = TAMC_GT911(I2C_SDA_PIN, I2C_SCL_PIN, TOUCH_INT, TOUCH_RST, 1024, 600);

struct tMyTouch
{
int x = 0;
int y = 0;
int cx = 0;
int cy = 0;

}MyTouch;

struct tTouchButton
{
int x;
int y;
int w;
int h;
}TouchButton;




void touch_init(void);
void pin_init();
tMyTouch touch_read();

void testFileIO(fs::FS &fs, const char * path);
void listDir(fs::FS &fs, const char * dirname, uint8_t levels);
bool onDecode(int16_t x, int16_t y, uint16_t w, uint16_t h, uint16_t* bitmap);


void drawBmp(const char *filename, int16_t x, int16_t y);
uint16_t read16(fs::File &f);
uint32_t read32(fs::File &f);



void setup(void)
{

    Serial.begin(115200);

      if(!SPIFFS.begin(FORMAT_SPIFFS_IF_FAILED)){
        Serial.println("SPIFFS Mount Failed");
        return;
    }
   
    Serial.println("Spiffs Init OK");

    listDir(SPIFFS, "/", 0);


    Serial.println("ESP32S3 7inch LCD");
      

    lcd.init();
    lcd.setRotation(0);
    lcd.setSwapBytes(1);

    lcd.fillScreen(TFT_WHITE);
    lcd.fillRect(0, 0, 50, 50, TFT_RED);
    pin_init();
    touch_init();  

    TJpgDec.setJpgScale(1);

  // The decoder must be given the exact name of the rendering function above
   TJpgDec.setCallback(onDecode);

   TJpgDec.getFsJpgSize(&w, &h, "/splash/DarkSky.jpg");
     TJpgDec.drawFsJpg(770, 50, "/splash/DarkSky.jpg"); 


    for (int i = 0; i < 11; i++ )
    {
     sprintf(Buffer,"/moon/moonphase_L%d.bmp",i );
     drawBmp(Buffer ,i * BitmapMoonX, 150);
    }
     
    for (int i = 0; i < 8; i++ )
    {
     sprintf(Buffer,"/wind/%s.bmp",Wind[i] );
     drawBmp(Buffer ,i * BitmapWindX, 225);
    }

    for (int i = 0; i < 15; i++ )
    {
     sprintf(Buffer,"/icon50/%s.bmp",Weather[i] );
     drawBmp(Buffer ,i * BitmapWindX, 370);
    }
 
   tft = &lcd;  
   Button.initButton(tft, 100, 500, 200, 50, TFT_GREEN,TFT_PINK,TFT_NAVY,Buffer,1,2);
   Button.drawButton(true, "Button 1");

 TouchButton.x = 100;
 TouchButton.y = 500;
 TouchButton.w = 200;
 TouchButton.h = 50;
 
 


}



bool CheckifPressed(tMyTouch Value)
{
bool Result = false;
/*
if(xp>10 && xp<80 && yp>30 && yp<80)
    {if(deb==0){deb=1; other[0]++; press=1;}}
*/
//if ((TouchButton.x > Value.x ) && (( TouchButton.w + TouchButton.x) < Value.x) && (TouchButton.y > Value.y) && ((TouchButton.y + TouchButton.h) < Value.y))
if (( Value.x > TouchButton.x) && (Value.y > TouchButton.y ))
{
Serial.printf("Stage 1 --- %d - %d\n", Value.x, Value.y );
 if (( Value.x < (TouchButton.x + TouchButton.w)) && ( Value.y < (TouchButton.y + TouchButton.h)))
 {
Serial.println("Stage 2");
  Result = true;
 }
}

return(Result);
}


void loop(void)
{
    tMyTouch Result;

    Result = touch_read();
    if (CheckifPressed(Result))
     {
    Button.press(true); 
    if (Button.isPressed())
    {
    Button.press(false); 
    Button.drawButton(true, "Button 1");
    Serial.print("Is Pressed");
    }
     }
    delay(100);
}

 
void pin_init()
{
    pinMode(lcd_BL, OUTPUT);
    pinMode(TOUCH_RST, OUTPUT);

    digitalWrite(lcd_BL, LOW);
    delay(100);
    digitalWrite(TOUCH_RST, LOW);
    delay(1000);
    digitalWrite(TOUCH_RST, HIGH);
    delay(1000);
    digitalWrite(TOUCH_RST, LOW);
    delay(1000);
    digitalWrite(TOUCH_RST, HIGH);
    delay(1000);
}

void touch_init(void)
{
    ts.setResolution(TOUCH_WIDTH, TOUCH_HEIGHT);
    
    Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN);
    ts.begin();
    ts.setRotation(TOUCH_ROTATION);
}


 tMyTouch touch_read()
{
 tMyTouch Result = {0};
    ts.read();
    if (ts.isTouched)
    {
#ifdef SCREEN_HD
        Result.x = map(ts.points[0].x, 0, 1024, 0, SCREEN_W);
        Result.y = map(ts.points[0].y, 0, 750, 0, SCREEN_H);
        
#endif
#ifdef SCREEN_NORMAL
        touch_last_x = map(ts.points[0].x, 1024, 200, 0, SCREEN_W);
        touch_last_y = map(ts.points[0].y, 600, 120, 0, SCREEN_H);

#endif

#ifdef Debug
        Serial.print("TS x: ");
        Serial.print(ts.points[0].x);
        Serial.print("TS y: ");
        Serial.print(ts.points[0].y);

        Serial.print("Display x: ");
        Serial.print(Result.x);
        Serial.print("Display y: ");
        //Serial.printf("Touch Pins %d  %d",  );
        Serial.println(Result.y);
#endif
       lcd.fillCircle(Result.x, Result.y, 5, TFT_NAVY);
       lcd.setTextSize(5);
       lcd.setCursor(30,10);
       lcd.printf("Touch X: %d - Y: %d", ts.points[0].x, ts.points[0].y);
       lcd.setCursor(30,55);
       lcd.printf("Display X: %d - Display Y: %d", Result.x, Result.y);
       ts.isTouched = false;
    }
    return (Result);
}


void listDir(fs::FS &fs, const char * dirname, uint8_t levels)
{
    Serial.printf("Listing directory: %s\r\n", dirname);

    File root = fs.open(dirname);
    if(!root){
        Serial.println("- failed to open directory");
        return;
    }
    if(!root.isDirectory()){
        Serial.println(" - not a directory");
        return;
    }

    File file = root.openNextFile();
    while(file){
        if(file.isDirectory()){
            Serial.print("  DIR : ");
            Serial.println(file.name());
            if(levels){
                listDir(fs, file.path(), levels -1);
            }
        } else {
            Serial.print("  FILE: ");
            Serial.print(file.name());
            Serial.print("\tSIZE: ");
            Serial.println(file.size());
        }
        file = root.openNextFile();
    }
}





void testFileIO(fs::FS &fs, const char * path)
{
    Serial.printf("Testing file I/O with %s\r\n", path);

    static uint8_t buf[512];
    size_t len = 0;
    File file = fs.open(path, FILE_WRITE);
    if(!file){
        Serial.println("- failed to open file for writing");
        return;
    }

    size_t i;
    Serial.print("- writing" );
    uint32_t start = millis();
    for(i=0; i<2048; i++){
        if ((i & 0x001F) == 0x001F){
          Serial.print(".");
        }
        file.write(buf, 512);
    }
    Serial.println("");
    uint32_t end = millis() - start;
    Serial.printf(" - %u bytes written in %lu ms\r\n", 2048 * 512, end);
    file.close();

    file = fs.open(path);
    start = millis();
    end = start;
    i = 0;
    if(file && !file.isDirectory()){
        len = file.size();
        size_t flen = len;
        start = millis();
        Serial.print("- reading" );
        while(len){
            size_t toRead = len;
            if(toRead > 512){
                toRead = 512;
            }
            file.read(buf, toRead);
            if ((i++ & 0x001F) == 0x001F){
              Serial.print(".");
            }
            len -= toRead;
        }
        Serial.println("");
        end = millis() - start;
        Serial.printf("- %u bytes read in %lu ms\r\n", flen, end);
        file.close();
    } else {
        Serial.println("- failed to open file for reading");
    }
}


bool onDecode(int16_t x, int16_t y, uint16_t w, uint16_t h, uint16_t* bitmap)
{
     // Stop further decoding as image is running off bottom of screen
  if ( y >= lcd.height() ) return 0;

  // This function will clip the image block rendering automatically at the lcd boundaries
  lcd.pushImage(x, y, w, h, bitmap);

  // This might work instead if you adapt the sketch to use the Adafruit_GFX library
  // lcd.drawRGBBitmap(x, y, bitmap, w, h);

  // Return 1 to decode next block
   
  return 1;
}


void drawBmp(const char *filename, int16_t x, int16_t y) 
{

  if ((x >= lcd.width()) || (y >= lcd.height())) return;

  fs::File bmpFS;

  // Open requested file on SD card
  bmpFS = SPIFFS.open(filename, "r");

  if (!bmpFS)
  {
    Serial.print("File not found");
    return;
  }

  uint32_t seekOffset;
  uint16_t w, h, row, col;
  uint8_t  r, g, b;

  uint32_t startTime = millis();

  if (read16(bmpFS) == 0x4D42)
  {
    read32(bmpFS);
    read32(bmpFS);
    seekOffset = read32(bmpFS);
    read32(bmpFS);
    w = read32(bmpFS);
    h = read32(bmpFS);

    if ((read16(bmpFS) == 1) && (read16(bmpFS) == 24) && (read32(bmpFS) == 0))
    {
      y += h - 1;

      bool oldSwapBytes = lcd.getSwapBytes();
      lcd.setSwapBytes(true);
      bmpFS.seek(seekOffset);

      uint16_t padding = (4 - ((w * 3) & 3)) & 3;
      uint8_t lineBuffer[w * 3 + padding];

      for (row = 0; row < h; row++) {
        
        bmpFS.read(lineBuffer, sizeof(lineBuffer));
        uint8_t*  bptr = lineBuffer;
        uint16_t* tptr = (uint16_t*)lineBuffer;
        // Convert 24 to 16-bit colours
        for (uint16_t col = 0; col < w; col++)
        {
          b = *bptr++;
          g = *bptr++;
          r = *bptr++;
          *tptr++ = ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
        }

        // Push the pixel row to screen, pushImage will crop the line if needed
        // y is decremented as the BMP image is drawn bottom up
        lcd.pushImage(x, y--, w, 1, (uint16_t*)lineBuffer);
      }
      lcd.setSwapBytes(oldSwapBytes);
      Serial.print("Loaded in "); Serial.print(millis() - startTime);
      Serial.println(" ms");
    }
    else Serial.println("BMP format not recognized.");
  }
  bmpFS.close();
}

// These read 16- and 32-bit types from the SD card file.
// BMP data is stored little-endian, Arduino is little-endian too.
// May need to reverse subscript order if porting elsewhere.

uint16_t read16(fs::File &f) 
{
  uint16_t result;
  ((uint8_t *)&result)[0] = f.read(); // LSB
  ((uint8_t *)&result)[1] = f.read(); // MSB
  return result;
}

uint32_t read32(fs::File &f)
 {
  uint32_t result;
  ((uint8_t *)&result)[0] = f.read(); // LSB
  ((uint8_t *)&result)[1] = f.read();
  ((uint8_t *)&result)[2] = f.read();
  ((uint8_t *)&result)[3] = f.read(); // MSB
  return result;
}



