# Getting started with the Sunton ESP32-S3 7 inch display, LovyanGFX and LVGL

Simple demo application how to use this display with LovyanGFX and LVGL.

Some more explanation you can find on https://www.haraldkreuzer.net/en/news/getting-started-makerfabs-esp32-s3-7-inch-display-lovyangfx-and-lvgl
